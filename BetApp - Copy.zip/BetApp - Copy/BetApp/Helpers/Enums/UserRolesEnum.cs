﻿namespace BetApp.Helpers.Enums
{
    public enum UserRolesEnum
    {
        User = 0, 
        Admin = 1
    }
}
