﻿namespace BetApp.Models.Identity
{
    public class AppLogin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
